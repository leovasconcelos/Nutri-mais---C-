/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.io.Serializable;

/**
 *
 * @author Leonardo Vasconcelos
 */
public class PassaDados implements Serializable {
    private String dado1;
    private String dado2;
    private String dado3;
    
    private String dado4;
    private String dado5;
    private String dado6;
    private String dado7;
    private String dado8;

    public String getDado4() {
        return dado4;
    }

    public void setDado4(String dado4) {
        this.dado4 = dado4;
    }

    public String getDado5() {
        return dado5;
    }

    public void setDado5(String dado5) {
        this.dado5 = dado5;
    }

    public String getDado6() {
        return dado6;
    }

    public void setDado6(String dado6) {
        this.dado6 = dado6;
    }

    public String getDado7() {
        return dado7;
    }

    public void setDado7(String dado7) {
        this.dado7 = dado7;
    }

    public String getDado8() {
        return dado8;
    }

    public void setDado8(String dado8) {
        this.dado8 = dado8;
    }

    
    public String getDado1() {
        return dado1;
    }

    public void setDado1(String dado1) {
        this.dado1 = dado1;
    }

    public String getDado2() {
        return dado2;
    }

    public void setDado2(String dado2) {
        this.dado2 = dado2;
    }

    public String getDado3() {
        return dado3;
    }

    public void setDado3(String dado3) {
        this.dado3 = dado3;
    }
    
    
    
}
